import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Atrin Performance Coach",
  description: "Atrin's adaptive strength and athletic-performance training app.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
